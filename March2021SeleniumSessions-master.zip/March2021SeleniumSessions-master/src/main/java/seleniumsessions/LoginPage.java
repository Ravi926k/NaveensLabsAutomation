package seleniumsessions;

public class LoginPage {

	public void m1() {
		System.out.println("naveen - m1");
	}

}
