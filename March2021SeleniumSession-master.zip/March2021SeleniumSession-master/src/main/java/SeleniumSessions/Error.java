package SeleniumSessions;

public class Error {
	
	public static final String TIME_OUT_WEB_ELEMENT_MSG = "Element not found...TimeOut...";
	public static final String TIME_OUT_FRAME_ELEMENT_MSG = "Frame not found...TimeOut...";
	public static final String TIME_OUT_ALERT_MSG = "Alert not found...TimeOut...";

	
	
	

}
