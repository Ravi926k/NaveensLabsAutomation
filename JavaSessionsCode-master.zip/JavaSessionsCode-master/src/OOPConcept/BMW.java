package OOPConcept;

public class BMW extends Car{
	
	//Method Overriding:
	//when the method name is same with the same number of arguments
	//in parent class as well as in child class
	public void start(){
		System.out.println("BMW--start");
	}
	
	
	public void theftSafety(){
		System.out.println("BMW--theftSafety");
	}
	
	
	
	
	

}
