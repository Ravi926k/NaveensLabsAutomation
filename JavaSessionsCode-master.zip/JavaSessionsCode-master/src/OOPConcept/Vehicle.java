package OOPConcept;

public class Vehicle {
	
	public void engine(){
		System.out.println("Vehicle--engine");
	}
	
	

}
